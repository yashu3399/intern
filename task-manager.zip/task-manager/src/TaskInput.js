import { useState } from "react";

// TaskInput Component: Contains the input field and Add Task button.
// Uses JSX attributes (value, onChange, onClick, placeholder) and
// controlled component pattern with local state.
function TaskInput({ onAdd }) {
  const [value, setValue] = useState("");

  const handleAdd = () => {
    const trimmed = value.trim();
    if (!trimmed) return;
    onAdd(trimmed);
    setValue("");
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleAdd();
  };

  return (
    <div className="task-input-wrapper">
      <input
        type="text"
        placeholder="Add a new task..."
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={handleKeyDown}
      />
      <button className="btn-add" onClick={handleAdd}>
        + Add Task
      </button>
    </div>
  );
}

export default TaskInput;
