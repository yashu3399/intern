import { useState, useEffect } from "react";
import "./App.css";
import TaskInput from "./TaskInput";
import TaskList from "./TaskList";

// App Component: Root component that manages the tasks state array.
// Handles add, toggle, and delete operations, passes handlers as props
// to child components, and persists data via localStorage.
function App() {
  // Initialize state from localStorage (bonus: persistence)
  const [tasks, setTasks] = useState(() => {
    try {
      const saved = localStorage.getItem("tm-tasks");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Sync to localStorage whenever tasks change
  useEffect(() => {
    localStorage.setItem("tm-tasks", JSON.stringify(tasks));
  }, [tasks]);

  // Add a new task
  const handleAdd = (text) => {
    const newTask = {
      id: Date.now(),
      text,
      status: "not-started", // New tasks start as "not-started"
    };
    setTasks((prev) => [newTask, ...prev]);
  };

  // Update task status
  const handleStatusChange = (id, newStatus) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: newStatus } : t))
    );
  };

  // Delete a task
  const handleDelete = (id) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  // Derived counts for the counter (JSX expressions)
  const total = tasks.length;
  const notStarted = tasks.filter((t) => t.status === "not-started").length;
  const inProgress = tasks.filter((t) => t.status === "in-progress").length;
  const completed = tasks.filter((t) => t.status === "completed").length;

  return (
    <div className="app">
      {/* Header */}
      <header className="app-header">
        <h1>
          My Task<span>.</span>
        </h1>

        {/* Conditional rendering: show counter only if tasks exist */}
        {total > 0 && (
          <div className="task-counter">
            <span className="counter-dot"></span>
            <span className="counter-item">
              <span className="counter-label">Not Started:</span>
              <span className="counter-number not-started">{notStarted}</span>
            </span>
            <span className="counter-item">
              <span className="counter-label">In Progress:</span>
              <span className="counter-number in-progress">{inProgress}</span>
            </span>
            <span className="counter-item">
              <span className="counter-label">Completed:</span>
              <span className="counter-number completed">{completed}</span>
            </span>
          </div>
        )}
      </header>

      {/* TaskInput Component */}
      <TaskInput onAdd={handleAdd} />

      {/* Section label */}
      <p className="tasks-section-label">Tasks</p>

      {/* TaskList Component */}
      <TaskList
        tasks={tasks}
        onStatusChange={handleStatusChange}
        onDelete={handleDelete}
      />
    </div>
  );
}

export default App;
