import TaskItem from "./TaskItem";

// TaskList Component: Receives the tasks array as a prop and renders
// each task using the map() function. Uses conditional rendering to
// display an empty-state message when no tasks exist.
function TaskList({ tasks, onStatusChange, onDelete }) {
  // Conditional rendering: empty state
  if (tasks.length === 0) {
    return (
      <div className="empty-state">
        <div className="empty-icon">📋</div>
        <p>No tasks available. Add one above!</p>
      </div>
    );
  }

  return (
    <div className="task-list">
      {/* map() renders a TaskItem for each task in the array */}
      {tasks.map((task) => (
        <TaskItem
          key={task.id}
          task={task}
          onStatusChange={onStatusChange}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
}

export default TaskList;
