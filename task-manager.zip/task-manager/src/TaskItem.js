// TaskItem Component: Renders a single task row with status dropdown,
// task text, status badge, and a delete button.
// Demonstrates JSX expressions, JSX attributes, and conditional rendering.
function TaskItem({ task, onStatusChange, onDelete }) {
  const statusOptions = [
    { value: "not-started", label: "Not Started", color: "#6e6e7a" },
    { value: "in-progress", label: "In Progress", color: "#ffa500" },
    { value: "completed", label: "Completed", color: "#c8f060" }
  ];

  const currentStatus = statusOptions.find(opt => opt.value === task.status) || statusOptions[0];

  return (
    <div className={`task-item status-${task.status}`}>
      {/* Status dropdown */}
      <select
        className="status-select"
        value={task.status}
        onChange={(e) => onStatusChange(task.id, e.target.value)}
      >
        {statusOptions.map(option => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>

      {/* Task text */}
      <span className="task-text">{task.text}</span>

      {/* Status badge */}
      <span 
        className="status-badge" 
        style={{ backgroundColor: currentStatus.color + "20", color: currentStatus.color }}
      >
        {currentStatus.label}
      </span>

      {/* Delete button */}
      <button
        className="btn-delete"
        onClick={() => onDelete(task.id)}
        title="Delete task"
      >
        ✕
      </button>
    </div>
  );
}

export default TaskItem;
